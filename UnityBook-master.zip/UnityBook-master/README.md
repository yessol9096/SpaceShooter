
<h2>절대강좌! 유니티 - 리소스 파일</h2>

"절대강좌! 유니티" 책에서 사용하는 리소스 파일입니다.
이 리소스는 개인 공부의 목적으로 만 사용하셔야 합니다.

Q&A는 [www.Unity3dStudy.com](http://www.unity3dstudy.com/books-qanda/) 에 글을 남겨주세요.

![UnityBook2018 Cover](http://IndieGameMaker.github.io/images/books/unity2018_cover.png)
